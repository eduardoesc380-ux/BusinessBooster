import * as React from "react";
import { cn } from "@/lib/utils";

const variants = {
  default:
    "bg-indigo-500 text-white hover:bg-indigo-600 focus-visible:ring-indigo-400",
  outline:
    "border border-slate-700/70 bg-transparent text-slate-100 hover:bg-slate-900/60 focus-visible:ring-slate-400",
};

export function Button({ className, variant = "default", ...props }) {
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center whitespace-nowrap rounded-2xl px-6 py-4 text-base font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-950 disabled:pointer-events-none disabled:opacity-50",
        variants[variant] || variants.default,
        className
      )}
      {...props}
    />
  );
}
