export const metadata = {
  title: "Business Booster",
  description:
    "Business Booster helps companies grow with professional websites, automated calls, and marketing & social media management.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
