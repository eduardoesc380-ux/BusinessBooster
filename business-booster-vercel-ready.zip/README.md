# Business Booster (Ready for Vercel)

## 1) Install
```bash
npm install
```

## 2) Run locally
```bash
npm run dev
```
Open http://localhost:3000

## 3) Deploy to Vercel
- Push this project to a GitHub repo
- In Vercel: **New Project** → Import repo → **Deploy**
